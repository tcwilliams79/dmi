DMI v0.1.9 - Deployment Instructions
=====================================

DEPLOYMENT OPTIONS:

Option 1: Subdirectory (e.g., dmianalysis.org/dashboard/)
----------------------------------------------------------
1. Upload all files in this directory to: public_html/dashboard/
2. Access at: https://dmianalysis.org/dashboard/

Option 2: Subdomain (e.g., data.dmianalysis.org)
-------------------------------------------------
1. Create subdomain in cPanel
2. Upload all files to subdomain's public_html/
3. Access at: https://data.dmianalysis.org/

Option 3: WordPress Integration
--------------------------------
1. Create a WordPress page template
2. Embed index.html content
3. Or use iframe: <iframe src="/dashboard/" width="100%" height="800px"></iframe>

FTP/SFTP Upload Instructions:
------------------------------
Host: ftp.yourdomain.com (check ifastnet docs)
Username: [your cpanel username]
Password: [your cpanel password]
Port: 21 (FTP) or 22 (SFTP)

Upload all files to:
- public_html/ (root domain)
- public_html/dashboard/ (subdirectory)
- or subdomain directory

File Manager Upload (cPanel):
------------------------------
1. Log into cPanel
2. Open File Manager
3. Navigate to public_html/ or subdirectory
4. Click Upload
5. Select all files from this deploy/ directory
6. Or compress to .zip and extract on server

Files Included:
---------------
- index.html (main dashboard)
- data/ directory (all DMI data files)
- .htaccess (caching and security)

Total Size: ~2 MB

IMPORTANT:
----------
- No server-side code required (pure static files)
- No database needed
- No PHP/Python/Node.js required
- Works on any web host with basic HTML support

Troubleshooting:
----------------
If data doesn't load:
1. Check browser console (F12) for errors
2. Verify data/outputs/ directory uploaded correctly
3. Check file permissions (644 for files, 755 for directories)
4. Clear browser cache

Support:
--------
GitHub: https://github.com/tcwilliams79/dmi
Docs: See docs/API.md for technical details
